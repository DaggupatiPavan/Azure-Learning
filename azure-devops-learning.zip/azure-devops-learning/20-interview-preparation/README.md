# Azure Interview Preparation

Preparation tracks:

- Fundamentals
- Networking
- Identity & Security
- AKS
- Terraform
- CI/CD
- Architecture
- Troubleshooting
- Scenario-based questions
- Senior DevOps / Platform Engineer interviews

Focus on explaining trade-offs rather than memorizing definitions.
