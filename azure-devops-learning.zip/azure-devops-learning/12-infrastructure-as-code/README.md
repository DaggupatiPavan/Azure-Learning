# Infrastructure as Code

## Tools

- Terraform
- Bicep
- Azure Resource Manager

## Engineering Goals

- Reusable modules
- Remote state
- State locking
- Secure secrets
- Plan/apply workflow
- CI validation
- Policy as code
- Drift detection

## Subsections

- [Terraform](./terraform/README.md)
- [Bicep](./bicep/README.md)
