# Terraform on Azure

Topics to build:

- AzureRM provider
- Resources and data sources
- Variables and outputs
- Modules
- State
- Remote state
- State locking
- Workspaces
- Import
- Drift
- CI/CD
- Azure Verified Modules
