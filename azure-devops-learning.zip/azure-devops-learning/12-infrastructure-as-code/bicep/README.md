# Bicep

Topics to build:

- Bicep syntax
- Parameters
- Variables
- Modules
- Outputs
- Existing resources
- Deployment scopes
- What-if
- CI/CD
- Bicep vs Terraform
