# Hands-on Labs

Labs are intentionally small and practical.

Each lab should eventually contain:

```text
README.md
terraform/
scripts/
diagrams/
```

## Lab Rules

- Use least privilege.
- Clean up billable resources.
- Never commit secrets.
- Prefer IaC.
- Document commands and expected output.
