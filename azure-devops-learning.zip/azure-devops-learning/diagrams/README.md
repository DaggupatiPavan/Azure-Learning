# Architecture Diagrams

All diagrams should use Mermaid where practical so they remain version-controlled and editable in GitHub.

Planned diagrams:

- Azure hierarchy
- Management groups
- Enterprise landing zone
- Hub-spoke
- Virtual WAN
- AKS architecture
- CI/CD
- Monitoring
- Security
- Enterprise reference architecture
