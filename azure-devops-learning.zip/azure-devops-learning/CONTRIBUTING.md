# Contributing

This repository is primarily a personal learning lab.

## Documentation

Prefer:

- Clear explanations
- Architecture diagrams
- Practical commands
- Terraform/Bicep examples
- Troubleshooting scenarios
- Official Microsoft references

## Security

Never commit:

- Passwords
- API keys
- Client secrets
- Certificates/private keys
- Terraform state containing sensitive values
