# Monitoring & Observability

> Azure Monitor, Log Analytics, Application Insights, KQL, alerts, diagnostics, observability.

## Purpose

This section will contain structured learning notes, architecture explanations, hands-on exercises, troubleshooting scenarios, and interview preparation.

## Learning Pattern

```text
Concept
  ↓
Why it matters
  ↓
Architecture
  ↓
Azure CLI
  ↓
Terraform / Bicep
  ↓
Hands-on Lab
  ↓
Troubleshooting
  ↓
Real-world Scenario
  ↓
Interview Questions
```

## Status

- [ ] Theory
- [ ] Architecture
- [ ] CLI practice
- [ ] Infrastructure as Code
- [ ] Hands-on lab
- [ ] Troubleshooting
- [ ] Interview preparation

## Official Documentation

https://learn.microsoft.com/azure/
