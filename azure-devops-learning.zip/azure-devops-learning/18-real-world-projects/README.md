# Real-world Projects

These projects combine multiple Azure capabilities.

## Project progression

1. Azure web application
2. Production AKS platform
3. Terraform Azure platform
4. Enterprise Landing Zone
5. End-to-end DevOps platform

Each project should contain architecture, requirements, IaC, CI/CD, security, monitoring, cost considerations, troubleshooting and a post-project review.
