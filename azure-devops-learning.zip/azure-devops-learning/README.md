# Azure DevOps Learning

> Azure Cloud • DevOps • Platform Engineering • Kubernetes • Terraform • Architecture

A structured, hands-on learning repository for building production-grade Azure DevOps and Platform Engineering skills.

## 🎯 Objective

Build from Azure fundamentals to enterprise architecture, AKS, Terraform, CI/CD, governance, troubleshooting, and real-world platform engineering.

## 🗺️ Roadmap

| Phase | Area | Status |
|---|---|---|
| 01 | Foundations | ⬜ |
| 02 | Identity & Access | ⬜ |
| 03 | Networking | ⬜ |
| 04 | Compute | ⬜ |
| 05 | Storage | ⬜ |
| 06 | Databases | ⬜ |
| 07 | Containers | ⬜ |
| 08 | Kubernetes / AKS | ⬜ |
| 09 | Security | ⬜ |
| 10 | Monitoring & Observability | ⬜ |
| 11 | Azure DevOps / CI-CD | ⬜ |
| 12 | Infrastructure as Code | ⬜ |
| 13 | Governance | ⬜ |
| 14 | CAF / WAF / Landing Zones | ⬜ |
| 15 | Architecture | ⬜ |
| 16 | Platform Engineering | ⬜ |
| 17 | Hands-on Labs | ⬜ |
| 18 | Real-world Projects | ⬜ |
| 19 | Troubleshooting | ⬜ |
| 20 | Interview Preparation | ⬜ |

## 📚 Learning Approach

For every major Azure topic:

1. Understand the concept
2. Understand why it exists
3. Map it to AWS where useful
4. Study the architecture
5. Use Azure CLI
6. Implement with Terraform/Bicep
7. Build a hands-on lab
8. Troubleshoot common failures
9. Apply it to a real-world scenario
10. Practice interview questions

## 🏗️ Architecture

See [`diagrams/`](./diagrams/).

## 🧪 Hands-on Labs

See [`17-hands-on-labs/`](./17-hands-on-labs/).

## 🚀 Real-world Projects

See [`18-real-world-projects/`](./18-real-world-projects/).

## 🛠️ Troubleshooting

See [`19-troubleshooting/`](./19-troubleshooting/).

## 🎯 Interview Preparation

See [`20-interview-preparation/`](./20-interview-preparation/).

## 📌 Repository Principles

- Prefer official Microsoft documentation.
- Learn services through architecture and use cases, not memorization.
- Use Infrastructure as Code wherever practical.
- Document trade-offs.
- Build production-oriented examples.
- Keep security and cost in every design.
- Explain architectures as if answering a senior DevOps interview.

## 🔗 Primary References

- Microsoft Learn: https://learn.microsoft.com/
- Azure Architecture Center: https://learn.microsoft.com/azure/architecture/
- Cloud Adoption Framework: https://learn.microsoft.com/azure/cloud-adoption-framework/
- Well-Architected Framework: https://learn.microsoft.com/azure/well-architected/

## 📈 Progress

Update the checkboxes above as each phase is completed.
