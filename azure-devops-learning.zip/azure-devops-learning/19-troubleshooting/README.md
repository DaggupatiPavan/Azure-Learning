# Azure Troubleshooting

Use a systematic approach:

```text
Symptom
  ↓
Scope
  ↓
Recent changes
  ↓
Identity
  ↓
Network
  ↓
Compute / Kubernetes
  ↓
Application
  ↓
Logs / Metrics
  ↓
Root Cause
  ↓
Fix
  ↓
Prevention
```
